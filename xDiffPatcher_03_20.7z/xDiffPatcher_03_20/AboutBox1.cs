﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace xDiffPatcher
{
    partial class AboutBox1 : Form
    {
        public AboutBox1()
        {
            InitializeComponent();

        }
    }
}
